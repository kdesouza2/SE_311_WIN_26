import java.util.List;

public interface Alphabetizer {

    public List<String> sort(List<String> lines);
    
}
