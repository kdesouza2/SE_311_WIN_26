import java.util.List;

public interface Input {

    public List<String> readLines();
}
