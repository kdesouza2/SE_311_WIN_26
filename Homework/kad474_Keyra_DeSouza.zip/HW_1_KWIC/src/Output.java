import java.util.List;

public interface Output {
    
    public void printOutput(List<String> lines);

    public void printOutputLine(String line);

}
